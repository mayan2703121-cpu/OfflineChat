# Offline Chat - Step 1
Bluetooth LE chat between nearby Android phones. No internet, no phone number.

Open this folder in Android Studio (File > Open), wait for Gradle sync, then Run on 2 real phones
(emulators do not support BLE). Both phones need Bluetooth ON and Android 8.0+.
