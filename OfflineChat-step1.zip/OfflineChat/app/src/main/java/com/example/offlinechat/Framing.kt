package com.example.offlinechat

import java.io.ByteArrayOutputStream

/** BLE packets are small, so long messages are cut into chunks. First byte: 1 = last chunk, 0 = more coming. */
object Framing {
    fun split(data: ByteArray, maxChunk: Int): List<ByteArray> {
        val body = maxOf(1, maxChunk - 1)
        val out = ArrayList<ByteArray>()
        var i = 0
        do {
            val end = minOf(i + body, data.size)
            val chunk = ByteArray(1 + end - i)
            chunk[0] = if (end >= data.size) 1.toByte() else 0.toByte()
            System.arraycopy(data, i, chunk, 1, end - i)
            out.add(chunk)
            i = end
        } while (i < data.size)
        return out
    }
}

class Reassembler {
    private val buf = ByteArrayOutputStream()

    fun feed(chunk: ByteArray): ByteArray? {
        if (chunk.isEmpty()) return null
        buf.write(chunk, 1, chunk.size - 1)
        if (chunk[0] == 1.toByte()) {
            val result = buf.toByteArray()
            buf.reset()
            return result
        }
        return null
    }
}
