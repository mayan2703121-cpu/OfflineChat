package com.example.offlinechat

data class ChatMessage(
    val id: String,
    val sender: String,
    val text: String,
    val time: Long,
    val mine: Boolean
)
