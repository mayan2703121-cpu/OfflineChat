package com.example.offlinechat

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothGattServer
import android.bluetooth.BluetoothGattServerCallback
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.bluetooth.le.BluetoothLeAdvertiser
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.ParcelUuid
import org.json.JSONObject
import java.util.UUID

/**
 * Every phone is BOTH a "server" (advertises + accepts connections) and a "client" (scans + connects).
 * All state is touched only on the main thread (callbacks hop over with main.post).
 * Messages are JSON, chunked by Framing, sent over every live link. Duplicates are dropped by message id (in ChatDb).
 */
@SuppressLint("MissingPermission")
@Suppress("DEPRECATION")
class BleChatManager(
    private val ctx: Context,
    private val identity: Identity,
    private val onMessage: (ChatMessage) -> Unit,
    private val onStatus: (String) -> Unit,
    private val onPeers: (List<String>) -> Unit
) {
    companion object {
        val SERVICE: UUID = UUID.fromString("7d5e0001-4c3a-4b8e-9a52-0f6c1b2a3d4e")
        val RX: UUID = UUID.fromString("7d5e0002-4c3a-4b8e-9a52-0f6c1b2a3d4e")   // others write to this
        val TX: UUID = UUID.fromString("7d5e0003-4c3a-4b8e-9a52-0f6c1b2a3d4e")   // we notify through this
        val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
        const val WANT_MTU = 247
    }

    private class ClientLink(val gatt: BluetoothGatt) {
        var rx: BluetoothGattCharacteristic? = null
        var payload = 20
        var name: String? = null
        var ready = false
        var busy = false
        val queue = ArrayDeque<ByteArray>()
        val re = Reassembler()
    }

    private class ServerLink(val device: BluetoothDevice) {
        var payload = 20
        var name: String? = null
        var subscribed = false
        var busy = false
        val queue = ArrayDeque<ByteArray>()
        val re = Reassembler()
    }

    private val main = Handler(Looper.getMainLooper())
    private val btManager = ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    private val adapter: BluetoothAdapter? = btManager.adapter
    private var server: BluetoothGattServer? = null
    private var txChar: BluetoothGattCharacteristic? = null
    private var scanner: BluetoothLeScanner? = null
    private var advertiser: BluetoothLeAdvertiser? = null
    private var running = false

    private val clients = HashMap<String, ClientLink>()
    private val connecting = HashSet<String>()
    private val servers = HashMap<String, ServerLink>()

    // ---------------------------------------------------------------- public API

    fun start() {
        val a = adapter
        if (a == null || !a.isEnabled) {
            onStatus("Bluetooth is off. Turn it on and reopen the app.")
            return
        }
        if (running) return
        running = true
        startServer()
        startAdvertising()
        startScanning()
        onStatus("Searching for nearby phones...")
    }

    fun stop() {
        running = false
        try { scanner?.stopScan(scanCb) } catch (_: Exception) {}
        try { advertiser?.stopAdvertising(advCb) } catch (_: Exception) {}
        clients.values.forEach { try { it.gatt.close() } catch (_: Exception) {} }
        try { server?.close() } catch (_: Exception) {}
        clients.clear(); servers.clear(); connecting.clear()
        server = null
    }

    fun send(m: ChatMessage) {
        val data = JSONObject()
            .put("t", "m").put("id", m.id).put("u", m.sender).put("x", m.text).put("ts", m.time)
            .toString().toByteArray()
        main.post {
            clients.values.filter { it.ready }.forEach { enqueueClient(it, data) }
            servers.values.filter { it.subscribed }.forEach { enqueueServer(it, data) }
        }
    }

    // ---------------------------------------------------------------- shared helpers

    private fun helloBytes(): ByteArray =
        JSONObject().put("t", "h").put("u", identity.display).toString().toByteArray()

    private fun handlePacket(bytes: ByteArray, setName: (String) -> Unit) {
        try {
            val j = JSONObject(String(bytes))
            when (j.getString("t")) {
                "h" -> { setName(j.getString("u")); publishPeers() }
                "m" -> onMessage(ChatMessage(j.getString("id"), j.getString("u"), j.getString("x"), j.getLong("ts"), false))
            }
        } catch (_: Exception) { /* ignore broken packets */ }
    }

    private fun publishPeers() {
        val names = (clients.values.mapNotNull { it.name } + servers.values.mapNotNull { it.name }).distinct()
        onPeers(names)
        onStatus(if (names.isEmpty()) "Searching for nearby phones..." else "Connected to ${names.size} phone(s)")
    }

    // ---------------------------------------------------------------- server side (others connect to us)

    private fun startServer() {
        val s = btManager.openGattServer(ctx, serverCb)
        if (s == null) { onStatus("Could not start Bluetooth server"); return }
        val svc = BluetoothGattService(SERVICE, BluetoothGattService.SERVICE_TYPE_PRIMARY)
        val rx = BluetoothGattCharacteristic(
            RX,
            BluetoothGattCharacteristic.PROPERTY_WRITE or BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE,
            BluetoothGattCharacteristic.PERMISSION_WRITE
        )
        val tx = BluetoothGattCharacteristic(TX, BluetoothGattCharacteristic.PROPERTY_NOTIFY, 0)
        tx.addDescriptor(
            BluetoothGattDescriptor(CCCD, BluetoothGattDescriptor.PERMISSION_READ or BluetoothGattDescriptor.PERMISSION_WRITE)
        )
        svc.addCharacteristic(rx)
        svc.addCharacteristic(tx)
        s.addService(svc)
        server = s
        txChar = tx
    }

    private val serverCb = object : BluetoothGattServerCallback() {
        override fun onConnectionStateChange(device: BluetoothDevice, status: Int, newState: Int) {
            main.post {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    servers[device.address] = ServerLink(device)
                } else {
                    servers.remove(device.address)
                    publishPeers()
                }
            }
        }

        override fun onMtuChanged(device: BluetoothDevice, mtu: Int) {
            main.post { servers[device.address]?.payload = mtu - 3 }
        }

        override fun onDescriptorWriteRequest(
            device: BluetoothDevice, requestId: Int, descriptor: BluetoothGattDescriptor,
            preparedWrite: Boolean, responseNeeded: Boolean, offset: Int, value: ByteArray?
        ) {
            if (responseNeeded) server?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, offset, null)
            val on = value?.contentEquals(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE) == true
            main.post {
                val l = servers[device.address] ?: return@post
                l.subscribed = on
                if (on) enqueueServer(l, helloBytes())
            }
        }

        override fun onCharacteristicWriteRequest(
            device: BluetoothDevice, requestId: Int, characteristic: BluetoothGattCharacteristic,
            preparedWrite: Boolean, responseNeeded: Boolean, offset: Int, value: ByteArray?
        ) {
            if (responseNeeded) server?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, offset, null)
            val v = value?.copyOf() ?: return
            main.post {
                val l = servers[device.address] ?: return@post
                l.re.feed(v)?.let { full -> handlePacket(full) { n -> l.name = n } }
            }
        }

        override fun onNotificationSent(device: BluetoothDevice, status: Int) {
            main.post {
                val l = servers[device.address] ?: return@post
                l.busy = false
                pumpServer(l)
            }
        }
    }

    private fun enqueueServer(l: ServerLink, data: ByteArray) {
        Framing.split(data, l.payload).forEach { l.queue.addLast(it) }
        pumpServer(l)
    }

    private fun pumpServer(l: ServerLink) {
        if (l.busy || !l.subscribed) return
        val chunk = l.queue.removeFirstOrNull() ?: return
        val c = txChar ?: return
        c.value = chunk
        l.busy = server?.notifyCharacteristicChanged(l.device, c, false) == true
    }

    // ---------------------------------------------------------------- advertising + scanning

    private val advCb = object : AdvertiseCallback() {
        override fun onStartFailure(errorCode: Int) { main.post { onStatus("Advertising failed (code $errorCode)") } }
    }

    private fun startAdvertising() {
        val adv = adapter?.bluetoothLeAdvertiser
        if (adv == null) { onStatus("This phone cannot advertise over Bluetooth LE"); return }
        advertiser = adv
        val settings = AdvertiseSettings.Builder()
            .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
            .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_HIGH)
            .setConnectable(true)
            .build()
        val data = AdvertiseData.Builder()
            .setIncludeDeviceName(false)
            .addServiceUuid(ParcelUuid(SERVICE))
            .build()
        adv.startAdvertising(settings, data, advCb)
    }

    private val scanCb = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            main.post {
                val addr = device.address
                if (!running || clients.containsKey(addr) || !connecting.add(addr)) return@post
                device.connectGatt(ctx, false, clientCb, BluetoothDevice.TRANSPORT_LE)
            }
        }

        override fun onScanFailed(errorCode: Int) { main.post { onStatus("Scan failed (code $errorCode)") } }
    }

    private fun startScanning() {
        val sc = adapter?.bluetoothLeScanner
        if (sc == null) { onStatus("Bluetooth scanner not available"); return }
        scanner = sc
        val filter = ScanFilter.Builder().setServiceUuid(ParcelUuid(SERVICE)).build()
        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()
        sc.startScan(listOf(filter), settings, scanCb)
    }

    // ---------------------------------------------------------------- client side (we connect to others)

    private val clientCb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            main.post {
                val addr = gatt.device.address
                if (newState == BluetoothProfile.STATE_CONNECTED && status == BluetoothGatt.GATT_SUCCESS) {
                    clients[addr] = ClientLink(gatt)
                    gatt.requestMtu(WANT_MTU)
                } else {
                    clients.remove(addr)
                    connecting.remove(addr)
                    try { gatt.close() } catch (_: Exception) {}
                    publishPeers()
                }
            }
        }

        override fun onMtuChanged(gatt: BluetoothGatt, mtu: Int, status: Int) {
            main.post {
                clients[gatt.device.address]?.payload = if (status == BluetoothGatt.GATT_SUCCESS) mtu - 3 else 20
                gatt.discoverServices()
            }
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            main.post {
                val l = clients[gatt.device.address] ?: return@post
                val svc = gatt.getService(SERVICE)
                val rx = svc?.getCharacteristic(RX)
                val tx = svc?.getCharacteristic(TX)
                val cccd = tx?.getDescriptor(CCCD)
                if (rx == null || tx == null || cccd == null) { gatt.disconnect(); return@post }
                l.rx = rx
                gatt.setCharacteristicNotification(tx, true)
                cccd.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                gatt.writeDescriptor(cccd)
            }
        }

        override fun onDescriptorWrite(gatt: BluetoothGatt, descriptor: BluetoothGattDescriptor, status: Int) {
            main.post {
                val l = clients[gatt.device.address] ?: return@post
                l.ready = status == BluetoothGatt.GATT_SUCCESS
                if (l.ready) enqueueClient(l, helloBytes())
            }
        }

        override fun onCharacteristicWrite(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, status: Int) {
            main.post {
                val l = clients[gatt.device.address] ?: return@post
                l.busy = false
                pumpClient(l)
            }
        }

        // Android 12 and older call this one
        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            val v = characteristic.value?.copyOf() ?: return
            onClientData(gatt, v)
        }

        // Android 13+ calls this one
        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            onClientData(gatt, value.copyOf())
        }
    }

    private fun onClientData(gatt: BluetoothGatt, v: ByteArray) {
        main.post {
            val l = clients[gatt.device.address] ?: return@post
            l.re.feed(v)?.let { full -> handlePacket(full) { n -> l.name = n } }
        }
    }

    private fun enqueueClient(l: ClientLink, data: ByteArray) {
        Framing.split(data, l.payload).forEach { l.queue.addLast(it) }
        pumpClient(l)
    }

    private fun pumpClient(l: ClientLink) {
        if (l.busy || !l.ready) return
        val rx = l.rx ?: return
        val chunk = l.queue.removeFirstOrNull() ?: return
        rx.value = chunk
        rx.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
        l.busy = l.gatt.writeCharacteristic(rx)
    }
}
