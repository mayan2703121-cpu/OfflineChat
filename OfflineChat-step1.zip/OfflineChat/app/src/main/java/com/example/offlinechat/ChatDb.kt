package com.example.offlinechat

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class ChatDb(ctx: Context) : SQLiteOpenHelper(ctx, "chat.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE messages(id TEXT PRIMARY KEY, sender TEXT, body TEXT, ts INTEGER, mine INTEGER)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    /** Returns true if the message was new (false = duplicate, already stored). */
    fun insert(m: ChatMessage): Boolean {
        val cv = ContentValues().apply {
            put("id", m.id); put("sender", m.sender); put("body", m.text)
            put("ts", m.time); put("mine", if (m.mine) 1 else 0)
        }
        return writableDatabase.insertWithOnConflict("messages", null, cv, SQLiteDatabase.CONFLICT_IGNORE) != -1L
    }

    fun all(): List<ChatMessage> {
        val out = ArrayList<ChatMessage>()
        readableDatabase.rawQuery("SELECT id,sender,body,ts,mine FROM messages ORDER BY ts", null).use { c ->
            while (c.moveToNext()) {
                out.add(ChatMessage(c.getString(0), c.getString(1), c.getString(2), c.getLong(3), c.getInt(4) == 1))
            }
        }
        return out
    }
}
