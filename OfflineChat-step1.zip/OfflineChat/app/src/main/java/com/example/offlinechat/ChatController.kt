package com.example.offlinechat

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.UUID

class ChatController(private val ctx: Context) {
    val identity = Identity(ctx)
    private val db = ChatDb(ctx)
    private var ble: BleChatManager? = null

    val messages = mutableStateListOf<ChatMessage>()
    var status by mutableStateOf("Not started")
    var peers by mutableStateOf<List<String>>(emptyList())
    var username by mutableStateOf(identity.username)

    init { messages.addAll(db.all()) }

    fun setUsername(name: String) {
        identity.username = name.trim()
        username = identity.username
    }

    fun start() {
        if (ble == null) {
            ble = BleChatManager(
                ctx, identity,
                onMessage = { m -> if (db.insert(m)) messages.add(m) },
                onStatus = { status = it },
                onPeers = { peers = it }
            )
        }
        ble?.start()
    }

    fun stop() { ble?.stop() }

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        val m = ChatMessage(UUID.randomUUID().toString().replace("-", "").take(12), identity.display, t, System.currentTimeMillis(), true)
        db.insert(m)
        messages.add(m)
        ble?.send(m)
    }
}
