package com.example.offlinechat

import android.content.Context
import android.util.Base64
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.spec.ECGenParameterSpec

/**
 * Your identity = a key pair made on this phone (no phone number, no server).
 * The username is just a label; the short fingerprint (#a3f9) tells apart people with the same name.
 * TODO (later step): move the private key into Android Keystore.
 */
class Identity(ctx: Context) {
    private val p = ctx.getSharedPreferences("identity", Context.MODE_PRIVATE)

    init { ensureKeys() }

    var username: String
        get() = p.getString("username", "") ?: ""
        set(v) { p.edit().putString("username", v).apply() }

    val fingerprint: String
        get() {
            val pub = Base64.decode(p.getString("pub", "") ?: "", Base64.NO_WRAP)
            val hash = MessageDigest.getInstance("SHA-256").digest(pub)
            return hash.take(2).joinToString("") { "%02x".format(it) }
        }

    val display: String get() = "$username#$fingerprint"

    private fun ensureKeys() {
        if (p.contains("pub")) return
        val gen = KeyPairGenerator.getInstance("EC")
        gen.initialize(ECGenParameterSpec("secp256r1"))
        val kp = gen.generateKeyPair()
        p.edit()
            .putString("pub", Base64.encodeToString(kp.public.encoded, Base64.NO_WRAP))
            .putString("priv", Base64.encodeToString(kp.private.encoded, Base64.NO_WRAP))
            .apply()
    }
}
